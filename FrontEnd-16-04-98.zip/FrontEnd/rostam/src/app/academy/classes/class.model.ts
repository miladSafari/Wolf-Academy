export class Class {
  public name : string;
  public classNumber : number;
  constructor(name : string,classNumber : number){
    this.classNumber= classNumber;
    this.name=name;
  }
}
