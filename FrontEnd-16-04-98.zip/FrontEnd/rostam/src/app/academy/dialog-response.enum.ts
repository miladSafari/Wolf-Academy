//TODO: use enum
// export enum DialogResponse {
//     OK,
//     Cancel
// }

export const OK:string = "OK";
export const Cancel:string = "Cancel";